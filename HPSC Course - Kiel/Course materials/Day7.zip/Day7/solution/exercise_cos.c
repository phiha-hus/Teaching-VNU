
#include "basic.h"

#define PRINT_N 5

real coeff[] = {
    1.0 / (1.0 * 2.0), 1.0 / (3.0 * 4.0), 1.0 / (5.0 * 6.0), 1.0 / (7.0 * 8.0),
    1.0 / (9.0 * 10.0), 1.0 / (11.0 * 12.0), 1.0 / (13.0 * 14.0), 1.0 / (15.0 * 16.0), 1.0 / (17.0 * 18.0), 1.0 / (19.0 * 20.0), 1.0 / (21.0 * 22.0), 1.0 / (23.0 * 24.0), 1.0 / (25.0 * 26.0), 1.0 / (27.0 * 28.0)};

static const double fpi = 3.14159265358979323846264338327950288L;
static const double fone_2pi = 1.0L / 6.28318530717958647692528676655900577L;

#pragma omp declare simd
real my_cos(real x)
{
    real x2;
    real res;

    x2 = x * x;

    res = 1.0 - coeff[6] * x2;
    res = 1.0 - coeff[5] * x2 * res;
    res = 1.0 - coeff[4] * x2 * res;
    res = 1.0 - coeff[3] * x2 * res;
    res = 1.0 - coeff[2] * x2 * res;
    res = 1.0 - coeff[1] * x2 * res;
    res = 1.0 - coeff[0] * x2 * res;

    return res;
}

__m256d my_cos_avx(__m256d xi)
{
    __m256d xi2, v_one, c;

    v_one = _mm256_set1_pd(1.0);

    xi2 = _mm256_mul_pd(xi, xi);

    c = _mm256_sub_pd(v_one, _mm256_mul_pd(_mm256_set1_pd(coeff[6]), xi2));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[5]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[4]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[3]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[2]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[1]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[0]))));

    return c;
}

__m256d my_cos_avx_arg_reduction(__m256d xi)
{
    __m256d xi2, v_one, c, n;

    v_one = _mm256_set1_pd(1.0);

    // compute floor(x / (2*pi))
    n = _mm256_floor_pd(_mm256_mul_pd(xi, _mm256_set1_pd(fone_2pi)));
    // n = 2 * n + 1
    n = _mm256_add_pd(_mm256_mul_pd(_mm256_set1_pd(2.0), n), v_one);

    //xi = xi - n * pi;
    xi = _mm256_sub_pd(xi, _mm256_mul_pd(n, _mm256_set1_pd(fpi)));

    xi2 = _mm256_mul_pd(xi, xi);

    c = _mm256_sub_pd(v_one, _mm256_mul_pd(_mm256_set1_pd(coeff[12]), xi2));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[11]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[10]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[9]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[8]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[7]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[6]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[5]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[4]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[3]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[2]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[1]))));
    c = _mm256_sub_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi2, _mm256_set1_pd(coeff[0]))));

    //correct the sign
    c = -c;

    return c;
}

real my_cos_pipeline(real x)
{
    real x2, x4;
    real res, res2;

    x2 = x * x;
    x4 = x2 * x2;

    res = 1.0 + coeff[6] * x4;
    res2 = 1.0 + coeff[5] * x4;

    res = 1.0 + coeff[4] * x4 * res;
    res2 = 1.0 + coeff[3] * x4 * res2;

    res = 1.0 + coeff[2] * x4 * res;
    res2 = 1.0 + coeff[1] * x4 * res2;

    res = res2 - x2 * coeff[0] * res;

    return res;
}

__m256d my_cos_avx_pipeline(__m256d xi)
{
    __m256d xi2, xi4, v_one, c, c2;

    v_one = _mm256_set1_pd(1.0);

    xi2 = _mm256_mul_pd(xi, xi);
    xi4 = _mm256_mul_pd(xi2, xi2);

    c = _mm256_add_pd(v_one, _mm256_mul_pd(_mm256_set1_pd(coeff[6]), xi4));
    c2 = _mm256_add_pd(v_one, _mm256_mul_pd(_mm256_set1_pd(coeff[5]), xi4));

    c = _mm256_add_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi4, _mm256_set1_pd(coeff[4]))));
    c2 = _mm256_add_pd(v_one, _mm256_mul_pd(c2, _mm256_mul_pd(xi4, _mm256_set1_pd(coeff[3]))));

    c = _mm256_add_pd(v_one, _mm256_mul_pd(c, _mm256_mul_pd(xi4, _mm256_set1_pd(coeff[2]))));
    c2 = _mm256_add_pd(v_one, _mm256_mul_pd(c2, _mm256_mul_pd(xi4, _mm256_set1_pd(coeff[1]))));

    c = _mm256_sub_pd(c2, _mm256_mul_pd(xi2, _mm256_mul_pd(_mm256_set1_pd(coeff[0]), c)));

    return c;
}

real max_abs_error(uint n, real *x, real *y)
{
    uint i;
    real err;

    real res;

    i = 0;
    res = fabs(x[i] - y[i]) / fabs(x[i]);

#pragma omp simd reduction(max \
                           : res)
    for (i = 1; i < n; i++)
    {
        err = fabs(x[i] - y[i]) / fabs(x[i]);
        res = UINT_MAX(err, res);
    }

    return res;
}

int main(int argc, char const *argv[])
{
    real *x, *y, *y2;
    pstopwatch sw;
    real scale, range;
    real t, t2;
    uint n;
    uint iter;
    uint i, j;
    real error;
    __m256d v_x, v_y;

    n = 1 << 10;
    iter = 1 << 18;
    sw = new_stopwatch();

    x = (real *)_mm_malloc(n * sizeof(real), 64);
    y = (real *)_mm_malloc(n * sizeof(real), 64);
    y2 = (real *)_mm_malloc(n * sizeof(real), 64);

    /**
     * Init vector x with random values
     */

    srand(42);
    scale = 1.0 / RAND_MAX;
    range = M_PI * 0.25;

    for (i = 0; i < n; i++)
    {
        x[i] = 2.0 * range * ((real)rand() * scale - 0.5);
    }

    printf("\nComputing cosine with libC implementation:\n");

    start_stopwatch(sw);

    for (j = 0; j < iter; j++)
    {
        for (i = 0; i < n; i++)
        {
            y[i] = cos(x[i]);
        }
    }
    t = stop_stopwatch(sw);
    printf("  %.3f s\n", t);

    for (i = 0; i < UINT_MIN(PRINT_N, n); i++)
    {
        printf("x = %+.15e, y = %+.15e\n", x[i], y[i]);
    }

    printf("\nComputing cosine with own implementation (scalar + auto-vectorization):\n");

    for (i = 0; i < n; i++)
    {
        y2[i] = 0.0;
    }

    start_stopwatch(sw);

    for (j = 0; j < iter; j++)
    {
#pragma omp simd
        for (i = 0; i < n; i++)
        {
            y2[i] = my_cos(x[i]);
        }
    }
    t2 = stop_stopwatch(sw);
    printf("  %.3f s\n", t2);
    error = max_abs_error(n, y, y2);
    printf("max error:\n");
    printf("  %.5e\n", error);
    printf("Speedup: %.2f\n", t / t2);

    for (i = 0; i < UINT_MIN(PRINT_N, n); i++)
    {
        printf("x = %+.15e, y = %+.15e\n", x[i], y2[i]);
    }

    printf("\nComputing cosine with own implementation (AVX):\n");

    for (i = 0; i < n; i++)
    {
        y2[i] = 0.0;
    }

    start_stopwatch(sw);

    for (j = 0; j < iter; j++)
    {
        // load values from 'x', store the results in 'y2'
        for (i = 0; i + 3 < n; i += 4)
        {
            v_x = _mm256_load_pd(x + i);
            v_y = my_cos_avx(v_x);
            _mm256_store_pd(y2 + i, v_y);
        }
    }
    t2 = stop_stopwatch(sw);
    printf("  %.3f s\n", t2);
    error = max_abs_error(n, y, y2);
    printf("max error:\n");
    printf("  %.5e\n", error);
    printf("Speedup: %.2f\n", t / t2);

    for (i = 0; i < UINT_MIN(PRINT_N, n); i++)
    {
        printf("x = %+.15e, y = %+.15e\n", x[i], y2[i]);
    }

    printf("\nComputing cosine with own implementation (scalar + auto-vectorization + pipelining):\n");

    for (i = 0; i < n; i++)
    {
        y2[i] = 0.0;
    }

    //prepare coefficients for new evaluation strategy
    coeff[0] = 1.0 / (1.0 * 2.0);
    for (i = 0; i < 3; i++)
    {
        coeff[2 * i + 1] = 1.0 / ((4 * i + 1) * (4 * i + 2) * (4 * i + 3) * (4 * i + 4));
        coeff[2 * i + 2] = 1.0 / ((4 * i + 3) * (4 * i + 4) * (4 * i + 5) * (4 * i + 6));
    }

    start_stopwatch(sw);

    for (j = 0; j < iter; j++)
    {
#pragma omp simd
        for (i = 0; i < n; i++)
        {
            y2[i] = my_cos_pipeline(x[i]);
        }
    }
    t2 = stop_stopwatch(sw);
    printf("  %.3f s\n", t2);
    error = max_abs_error(n, y, y2);
    printf("max error:\n");
    printf("  %.5e\n", error);
    printf("Speedup: %.2f\n", t / t2);

    for (i = 0; i < UINT_MIN(PRINT_N, n); i++)
    {
        printf("x = %+.15e, y = %+.15e\n", x[i], y2[i]);
    }

    printf("\nComputing cosine with own implementation (AVX + pipeline):\n");

    for (i = 0; i < n; i++)
    {
        y2[i] = 0.0;
    }

    start_stopwatch(sw);

    for (j = 0; j < iter; j++)
    {
        // load values from 'x', store the results in 'y2'
        for (i = 0; i + 3 < n; i += 4)
        {
            v_x = _mm256_load_pd(x + i);
            v_y = my_cos_avx_pipeline(v_x);
            _mm256_store_pd(y2 + i, v_y);
        }
    }
    t2 = stop_stopwatch(sw);
    printf("  %.3f s\n", t2);
    error = max_abs_error(n, y, y2);
    printf("max error:\n");
    printf("  %.5e\n", error);
    printf("Speedup: %.2f\n", t / t2);

    for (i = 0; i < UINT_MIN(PRINT_N, n); i++)
    {
        printf("x = %+.15e, y = %+.15e\n", x[i], y2[i]);
    }

    freemem(x);
    freemem(y);
    freemem(y2);
    del_stopwatch(sw);

    return 0;
}
