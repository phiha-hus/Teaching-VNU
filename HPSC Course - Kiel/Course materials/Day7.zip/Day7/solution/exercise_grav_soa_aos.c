#include "basic.h"

#define GAMMA 1.0e-5
#define EPS_APPRX 1.0e-100

struct _grav_aos
{
    real pos[3];
    real vel[3];
    real force[3];
    real mass;
};

typedef struct _grav_aos grav_aos;
typedef grav_aos *pgrav_aos;

pgrav_aos new_grav_aos(uint n)
{
    uint i;
    real scale = 1.0 / RAND_MAX;

    pgrav_aos bodies;

    bodies = (pgrav_aos)allocmem(n * sizeof(grav_aos));

    srand(42);

#pragma omp parallel for
    for (i = 0; i < n; i++)
    {
        // set some random positions
        bodies[i].pos[0] = (real)rand() * scale;
        bodies[i].pos[1] = (real)rand() * scale;
        bodies[i].pos[2] = (real)rand() * scale;
        // set velocities to zero
        bodies[i].vel[0] = 0.0;
        bodies[i].vel[1] = 0.0;
        bodies[i].vel[2] = 0.0;
        // set forces to zero
        bodies[i].force[0] = 0.0;
        bodies[i].force[1] = 0.0;
        bodies[i].force[2] = 0.0;
        // set some random masses
        bodies[i].mass = 10.0 + 10.0 * ((real)rand() * scale);
    }

    return bodies;
}

void eval_force_aos(pgrav_aos bodies, uint n)
{
    real gamma = GAMMA;
    uint i, j;
    real sum[3];
    real dist[3];
    real norm;
    real m;

#pragma omp parallel for private(j, sum, dist, norm, m)
    for (i = 0; i < n; i++)
    {
        // compute forces
        sum[0] = 0.0;
        sum[1] = 0.0;
        sum[2] = 0.0;

#pragma omp simd reduction(+ \
                           : sum)
        for (j = 0; j < n; j++)
        {
            if (i != j)
            {
                // Get the mass m_j
                m = bodies[j].mass;

                // Distance vector
                dist[0] = bodies[j].pos[0] - bodies[i].pos[0];
                dist[1] = bodies[j].pos[1] - bodies[i].pos[1];
                dist[2] = bodies[j].pos[2] - bodies[i].pos[2];

                norm = dist[0] * dist[0] + dist[1] * dist[1] + dist[2] * dist[2];
                norm = 1.0 / sqrt(norm);
                norm = m * norm * norm * norm;

                sum[0] += dist[0] * norm;
                sum[1] += dist[1] * norm;
                sum[2] += dist[2] * norm;
            }
        }

        // set forces
        bodies[i].force[0] = bodies[i].mass * gamma * sum[0];
        bodies[i].force[1] = bodies[i].mass * gamma * sum[1];
        bodies[i].force[2] = bodies[i].mass * gamma * sum[2];
    }
}

struct _grav_soa
{
    uint n;

    real *pos_x;
    real *pos_y;
    real *pos_z;

    real *vel_x;
    real *vel_y;
    real *vel_z;

    real *force_x;
    real *force_y;
    real *force_z;

    real *mass;
};

typedef struct _grav_soa grav_soa;
typedef grav_soa *pgrav_soa;

pgrav_soa new_grav_soa(uint n)
{
    uint i;
    real scale = 1.0 / RAND_MAX;

    pgrav_soa bodies;

    bodies = (pgrav_soa)allocmem(sizeof(grav_soa));
    bodies->pos_x = (real *)allocmem(n * sizeof(real));
    bodies->pos_y = (real *)allocmem(n * sizeof(real));
    bodies->pos_z = (real *)allocmem(n * sizeof(real));
    bodies->vel_x = (real *)allocmem(n * sizeof(real));
    bodies->vel_y = (real *)allocmem(n * sizeof(real));
    bodies->vel_z = (real *)allocmem(n * sizeof(real));
    bodies->force_x = (real *)allocmem(n * sizeof(real));
    bodies->force_y = (real *)allocmem(n * sizeof(real));
    bodies->force_z = (real *)allocmem(n * sizeof(real));
    bodies->mass = (real *)allocmem(n * sizeof(real));

    srand(42);

    bodies->n = n;
#pragma omp parallel for
    for (i = 0; i < n; i++)
    {
        // set some random positions
        bodies->pos_x[i] = (real)rand() * scale;
        bodies->pos_y[i] = (real)rand() * scale;
        bodies->pos_z[i] = (real)rand() * scale;
        // set velocities to zero
        bodies->vel_x[i] = 0.0;
        bodies->vel_y[i] = 0.0;
        bodies->vel_z[i] = 0.0;
        // set forces to zero
        bodies->force_x[i] = 0.0;
        bodies->force_y[i] = 0.0;
        bodies->force_z[i] = 0.0;
        // set some random masses
        bodies->mass[i] = 10.0 + 10.0 * ((real)rand() * scale);
    }

    return bodies;
}

void eval_force_soa(pgrav_soa bodies)
{
    uint n = bodies->n;
    real gamma = GAMMA;
    uint i, j;
    real sum[3];
    real dist[3];
    real norm;
    real m;

#pragma omp parallel for private(j, sum, dist, norm, m)
    for (i = 0; i < n; i++)
    {
        // compute forces
        sum[0] = 0.0;
        sum[1] = 0.0;
        sum[2] = 0.0;

#pragma omp simd reduction(+ \
                           : sum)
        for (j = 0; j < i; j++)
        {
            // Get the mass m_j
            m = bodies->mass[j];

            // Distance vector
            dist[0] = bodies->pos_x[j] - bodies->pos_x[i];
            dist[1] = bodies->pos_y[j] - bodies->pos_y[i];
            dist[2] = bodies->pos_z[j] - bodies->pos_z[i];

            norm = dist[0] * dist[0] + dist[1] * dist[1] + dist[2] * dist[2];
            norm = 1.0 / sqrt(norm);
            norm = m * norm * norm * norm;

            sum[0] += dist[0] * norm;
            sum[1] += dist[1] * norm;
            sum[2] += dist[2] * norm;
        }

#pragma omp simd reduction(+ \
                           : sum)
        for (j = i + 1; j < n; j++)
        {
            // Get the mass m_j
            m = bodies->mass[j];

            // Distance vector
            dist[0] = bodies->pos_x[j] - bodies->pos_x[i];
            dist[1] = bodies->pos_y[j] - bodies->pos_y[i];
            dist[2] = bodies->pos_z[j] - bodies->pos_z[i];

            norm = dist[0] * dist[0] + dist[1] * dist[1] + dist[2] * dist[2];
            norm = 1.0 / sqrt(norm);
            norm = m * norm * norm * norm;

            sum[0] += dist[0] * norm;
            sum[1] += dist[1] * norm;
            sum[2] += dist[2] * norm;
        }

        // set forces
        bodies->force_x[i] = bodies->mass[i] * gamma * sum[0];
        bodies->force_y[i] = bodies->mass[i] * gamma * sum[1];
        bodies->force_z[i] = bodies->mass[i] * gamma * sum[2];
    }
}

int main(int argc, char const *argv[])
{

    uint n;
    pstopwatch sw;
    pgrav_aos aos;
    pgrav_soa soa;

    sw = new_stopwatch();

    n = 32768;

    printf("Init problem:\n");
    start_stopwatch(sw);
    aos = new_grav_aos(n);
    soa = new_grav_soa(n);
    printf("  %.2f s\n", stop_stopwatch(sw));

    printf("Computing gravitational forces for %d bodies with array of structures (AoS):\n", n);
    start_stopwatch(sw);
    eval_force_aos(aos, n);
    printf("  1 Step with array of structures (AoS) took %.3f s\n", stop_stopwatch(sw));

    printf("Computing gravitational forces for %d bodies with structure of arrays (SoA):\n", n);
    start_stopwatch(sw);
    eval_force_soa(soa);
    printf("  1 Step with structure of arrays (SoA) took %.3f s\n", stop_stopwatch(sw));

    del_stopwatch(sw);

    return 0;
}
