#include "basic.h"

#define GAMMA 1.0e-5
#define EPS_APPRX 1.0e-100

struct _grav_aos
{
    real pos[3];
    real vel[3];
    real force[3];
    real mass;
};

typedef struct _grav_aos grav_aos;
typedef grav_aos *pgrav_aos;

pgrav_aos new_grav_aos(uint n)
{
    uint i;
    real scale = 1.0 / RAND_MAX;

    pgrav_aos bodies;

    bodies = (pgrav_aos)allocmem(n * sizeof(grav_aos));

    srand(42);

#pragma omp parallel for
    for (i = 0; i < n; i++)
    {
        // set some random positions
        bodies[i].pos[0] = (real)rand() * scale;
        bodies[i].pos[1] = (real)rand() * scale;
        bodies[i].pos[2] = (real)rand() * scale;
        // set velocities to zero
        bodies[i].vel[0] = 0.0;
        bodies[i].vel[1] = 0.0;
        bodies[i].vel[2] = 0.0;
        // set forces to zero
        bodies[i].force[0] = 0.0;
        bodies[i].force[1] = 0.0;
        bodies[i].force[2] = 0.0;
        // set some random masses
        bodies[i].mass = 10.0 + 10.0 * ((real)rand() * scale);
    }

    return bodies;
}

void eval_force_aos(pgrav_aos bodies, uint n)
{
    /**
     * TODO: Implement the gravitational forces computation with the aos layout 
     */
}

struct _grav_soa
{
    uint n;

    real *pos_x;
    real *pos_y;
    real *pos_z;

    real *vel_x;
    real *vel_y;
    real *vel_z;

    real *force_x;
    real *force_y;
    real *force_z;

    real *mass;
};

typedef struct _grav_soa grav_soa;
typedef grav_soa *pgrav_soa;

pgrav_soa new_grav_soa(uint n)
{
    uint i;
    real scale = 1.0 / RAND_MAX;

    pgrav_soa bodies;

    bodies = (pgrav_soa)allocmem(sizeof(grav_soa));
    bodies->pos_x = (real *)allocmem(n * sizeof(real));
    bodies->pos_y = (real *)allocmem(n * sizeof(real));
    bodies->pos_z = (real *)allocmem(n * sizeof(real));
    bodies->vel_x = (real *)allocmem(n * sizeof(real));
    bodies->vel_y = (real *)allocmem(n * sizeof(real));
    bodies->vel_z = (real *)allocmem(n * sizeof(real));
    bodies->force_x = (real *)allocmem(n * sizeof(real));
    bodies->force_y = (real *)allocmem(n * sizeof(real));
    bodies->force_z = (real *)allocmem(n * sizeof(real));
    bodies->mass = (real *)allocmem(n * sizeof(real));

    srand(42);

    bodies->n = n;
#pragma omp parallel for
    for (i = 0; i < n; i++)
    {
        // set some random positions
        bodies->pos_x[i] = (real)rand() * scale;
        bodies->pos_y[i] = (real)rand() * scale;
        bodies->pos_z[i] = (real)rand() * scale;
        // set velocities to zero
        bodies->vel_x[i] = 0.0;
        bodies->vel_y[i] = 0.0;
        bodies->vel_z[i] = 0.0;
        // set forces to zero
        bodies->force_x[i] = 0.0;
        bodies->force_y[i] = 0.0;
        bodies->force_z[i] = 0.0;
        // set some random masses
        bodies->mass[i] = 10.0 + 10.0 * ((real)rand() * scale);
    }

    return bodies;
}

void eval_force_soa(pgrav_soa bodies)
{
    /**
     * TODO: Implement the gravitational forces computation with the soa layout 
     */
}

int main(int argc, char const *argv[])
{

    uint n;
    pstopwatch sw;
    pgrav_aos aos;
    pgrav_soa soa;

    sw = new_stopwatch();

    n = 32768;

    printf("Init problem:\n");
    start_stopwatch(sw);
    aos = new_grav_aos(n);
    soa = new_grav_soa(n);
    printf("  %.2f s\n", stop_stopwatch(sw));

    printf("Computing gravitational forces for %d bodies with array of structures (AoS):\n", n);
    start_stopwatch(sw);
    eval_force_aos(aos, n);
    printf("  1 Step with array of structures (AoS) took %.3f s\n", stop_stopwatch(sw));

    printf("Computing gravitational forces for %d bodies with structure of arrays (SoA):\n", n);
    start_stopwatch(sw);
    eval_force_soa(soa);
    printf("  1 Step with structure of arrays (SoA) took %.3f s\n", stop_stopwatch(sw));

    del_stopwatch(sw);

    return 0;
}
