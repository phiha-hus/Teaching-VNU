
#include "basic.h"

#define PRINT_N 5

real coeff[] = {
    1.0 / (1.0 * 2.0), 1.0 / (3.0 * 4.0), 1.0 / (5.0 * 6.0), 1.0 / (7.0 * 8.0),
    1.0 / (9.0 * 10.0), 1.0 / (11.0 * 12.0), 1.0 / (13.0 * 14.0), 1.0 / (15.0 * 16.0), 1.0 / (17.0 * 18.0), 1.0 / (19.0 * 20.0), 1.0 / (21.0 * 22.0), 1.0 / (23.0 * 24.0), 1.0 / (25.0 * 26.0), 1.0 / (27.0 * 28.0)};

real my_cos(real x)
{

/**
 * TODO: Implement the taylor series for the cosine function, scalar version
 */

}

__m256d my_cos_avx(__m256d xi)
{

/**
 * TODO: Implement the taylor series for the cosine function, AVX intrinsics version
 */
}

real max_abs_error(uint n, real *x, real *y)
{
    uint i;
    real err;

    real res;

    i = 0;
    res = fabs(x[i] - y[i]) / fabs(x[i]);

#pragma omp simd reduction(max \
                           : res)
    for (i = 1; i < n; i++)
    {
        err = fabs(x[i] - y[i]) / fabs(x[i]);
        res = UINT_MAX(err, res);
    }

    return res;
}

int main(int argc, char const *argv[])
{
    real *x, *y, *y2;
    pstopwatch sw;
    real scale, amp;
    real t, t2;
    uint n;
    uint iter;
    uint i, j;
    real error;
    __m256d v_x, v_y;

    n = 1 << 12;
    iter = 1 << 14;
    sw = new_stopwatch();

    x = (real *)allocmem(n * sizeof(real));
    y = (real *)allocmem(n * sizeof(real));
    y2 = (real *)allocmem(n * sizeof(real));

    /**
     * Init vector x with random values
     */

    srand(42);
    scale = 1.0 / RAND_MAX;
    amp = M_PI * 0.25;

    for (i = 0; i < n; i++)
    {
        x[i] = 2.0 * amp * ((real)rand() * scale - 0.5);
    }

    printf("\nComputing cosine with libC implementation:\n");

    start_stopwatch(sw);

    for (j = 0; j < iter; j++)
    {
        for (i = 0; i < n; i++)
        {
            y[i] = cos(x[i]);
        }
    }
    t = stop_stopwatch(sw);
    printf("  %.3f s\n", t);

    for (i = 0; i < UINT_MIN(PRINT_N, n); i++)
    {
        printf("x = %+.15e, y = %+.15e\n", x[i], y[i]);
    }

    printf("\nComputing cosine with own implementation (scalar + auto-vectorization):\n");

    for (i = 0; i < n; i++)
    {
        y2[i] = 0.0;
    }

    start_stopwatch(sw);

    for (j = 0; j < iter; j++)
    {
        for (i = 0; i < n; i++)
        {
            y2[i] = my_cos(x[i]);
        }
    }
    t2 = stop_stopwatch(sw);
    printf("  %.3f s\n", t2);
    error = max_abs_error(n, y, y2);
    printf("max error:\n");
    printf("  %.5e\n", error);
    printf("Speedup: %.2f\n", t / t2);

    for (i = 0; i < UINT_MIN(PRINT_N, n); i++)
    {
        printf("x = %+.15e, y = %+.15e\n", x[i], y2[i]);
    }

    printf("\nComputing cosine with own implementation (AVX):\n");

    for (i = 0; i < n; i++)
    {
        y2[i] = 0.0;
    }

    start_stopwatch(sw);

    for (j = 0; j < iter; j++)
    {
        // load values from 'x', store the results in 'y2'

        /**
	 * TODO: Load, compute and store with AVX. Build a similar loop
	 *       as in the other cases.
	 */
    }
    t2 = stop_stopwatch(sw);
    printf("  %.3f s\n", t2);
    error = max_abs_error(n, y, y2);
    printf("max error:\n");
    printf("  %.5e\n", error);
    printf("Speedup: %.2f\n", t / t2);

    for (i = 0; i < UINT_MIN(PRINT_N, n); i++)
    {
        printf("x = %+.15e, y = %+.15e\n", x[i], y2[i]);
    }

    freemem(x);
    freemem(y);
    freemem(y2);
    del_stopwatch(sw);

    return 0;
}
