#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#include "wavestate2d.h"

int main(int argc, char **argv)
{
  pwavestate2d wv;
  real delta, t_current;
  double t_start, t_end, t_run, t_longest;
  int size, rank;
  int n, steps, substeps;
  int i;

  n = 200;
  delta = 0.01 / n;
  steps = 100000;
  substeps = 4;

  MPI_Init(&argc, &argv);

  MPI_Comm_size(MPI_COMM_WORLD, &size);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

  if (argc == 2)
  {
    substeps = atoi(argv[1]);
  }

  wv = new_wavestate2d(n, n, substeps, 1.0 / (n + 1), 1.0);

  t_start = MPI_Wtime();

  t_current = 0.0;
  for (i = 0; i < steps; i += substeps)
  {
    multileapfrog_wavestate2d(wv, t_current, delta);
    t_current += delta * substeps;

    if (rank == 0)
      if (100 * (i + substeps) / steps != 100 * i / steps)
      {
        printf("  [%3d%%]\r", 100 * (i + 1) / steps);
        fflush(stdout);
      }

#if 0 /* enable this for nice intermediate results. */
    if (i % (substeps * 50) == 0)
    {
      char buf[40];
      snprintf(buf, 40, "data/out-%07d.pnm", i);
      print_wavestate2d(wv, buf);
    }
#endif
  }

  t_end = MPI_Wtime();

  t_run = t_end - t_start;

  MPI_Reduce(&t_run, &t_longest, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

  if (rank == 0)
  {
    printf("  [100%%] %d timesteps\n"
           "  %.1f seconds\n",
           i, t_longest);
  }

  print_wavestate2d(wv, "out.pnm");

  del_wavestate2d(wv);

  MPI_Finalize();

  return 0;
}
