#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <assert.h>

#include "basic.h"

static int N = 8;
static int M = 16;

#define OUTPUT 0 // rank of the process, that should print its part of the matrix.

/*
 * Transpose a m times n matrix A into a n times m matrix B.
 *
 * Both matrices are assumed to be stored in block column distribution.
 * 
 * n is equal to N / #processes but m is equal to M.
 */
void transpose_matrix(double *A, double *B, int m, int n)
{

  /**
   *  TODO: Write the matrix A into the matrix B.
   * 
   *   The part of A, that is stored on each process has 'm' rows and 'n' columns.  
   *   The total matrix A considerd has there 'm' rows and 'n' * size many columns.
   *   The same holds for the transposed matrix B with exchanges dimensions.
   */
}

/*
 * Print a m times n matrix A to stdout.
 */
void print_matrix(double *A, int m, int n)
{
  int i, j;

  for (i = 0; i < m; ++i)
  {
    for (j = 0; j < n; ++j)
    {
      printf("%04.0f ", A[i + j * m]);
    }
    printf("\n");
  }
}

void check_transpose(double *B, int n, int m)
{
  int i, j, k, rank, size, sliceN;
  int error;
  double x, x1;

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  sliceN = n / size;
  error = 0;

  for (j = 0; j < m; j++)
  {
    for (k = 0; k < size; k++)
    {
      for (i = 0; i < sliceN; i++)
      {
        x = B[i + k * sliceN + j * n];
        x1 = rank * m + j + 1 + i * m * size + k * 1000;
        if (x != x1)
        {
          printf("%d: B(%d,%d) should be %04.0f but is %04.0f\n", rank, i + k * sliceN, j, x1, x);
          error++;
        }
      }
    }
  }

  MPI_Barrier(MPI_COMM_WORLD);
  printf("\nprocess %d: %d errors found.\n\n", rank, error);
  MPI_Barrier(MPI_COMM_WORLD);
}

int main(int argc, char **argv)
{
  int rank, size;
  int sliceM, sliceN;
  int i, j;
  double *A, *B;
  pstopwatch sw;

  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  /* Test if both rows and columns are divisible by number of processes. */
  assert(!(M % size));
  assert(!(N % size));

  sw = new_stopwatch();

  /* Determine slice size for rows and columns. */
  sliceM = M / size;
  sliceN = N / size;

  /* Allocate memory */
  A = (double *)malloc(M * sliceN * sizeof(double)); // M rows, but only N / size many columns
  B = (double *)malloc(N * sliceM * sizeof(double)); // N rows, but only M / size many columns

  /* Init values of A with globally unique values */
  for (j = 0; j < sliceN; ++j)
  {
    for (i = 0; i < M; ++i)
    {
      A[i + j * M] = rank * 1000 + (1.0 + i + j * M);
    }
  }

  /* Transpose the matrix */
  start_stopwatch(sw);
  transpose_matrix(A, B, M, sliceN);

  /* Check the results */
  check_transpose(B, N, sliceM);

  /* Print out both matrices if the dimensions are small enough */
  if (rank == OUTPUT && N <= 32 && M <= 32)
  {
    printf("Matrix A of process %d\n", OUTPUT);
    print_matrix(A, M, sliceN);
    printf("\n\n");
    printf("Matrix B of process %d\n", OUTPUT);
    print_matrix(B, N, sliceM);
  }

  /* cleanup */

  MPI_Finalize();

  free(A);
  free(B);
  del_stopwatch(sw);

  return 0;
}
