#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <assert.h>

#include "basic.h"

static int N = 8;
static int M = 16;

#define OUTPUT 0

/*
 * Transpose a m times n matrix A into a n times m matrix B.
 *
 * Both matrices are assumed to be stored in block column distribution.
 * 
 * n is equal to N / #processes but m is equal to M.
 */
void transpose_matrix(double *A, double *B, int m, int n)
{
  int size;
  int i, j, k, l, sliceM, rank;
  double *buf;

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  sliceM = m / size;

  buf = (double *)malloc(n * m * sizeof(double));

  for (i = 0; i < n; i++)
  {
    MPI_Alltoall(A + i * m, sliceM, MPI_DOUBLE, buf + i * m, sliceM, MPI_DOUBLE, MPI_COMM_WORLD);
  }

  k = 0;
  for (l = 0; l < sliceM; l++)
  {
    for (j = 0; j < size; j++)
    {
      for (i = 0; i < n; i++)
      {
        B[k++] = buf[i * m + l + j * sliceM];
      }
    }
  }

  free(buf);
}

/*
 * Print a m times n matrix A to stdout.
 */
void print_matrix(double *A, int m, int n)
{
  int i, j;

  for (i = 0; i < m; ++i)
  {
    for (j = 0; j < n; ++j)
    {
      printf("%04.0f ", A[i + j * m]);
    }
    printf("\n");
  }
}

void check_transpose(double *B, int n, int m)
{
  int i, j, k, rank, size, sliceN;
  int error;
  double x, x1;

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  sliceN = n / size;
  error = 0;

  for (j = 0; j < m; j++)
  {
    for (k = 0; k < size; k++)
    {
      for (i = 0; i < sliceN; i++)
      {
        x = B[i + k * sliceN + j * n];
        x1 = rank * m + j + 1 + i * m * size + k * 1000;
        if (x != x1)
        {
          printf("%d: B(%d,%d) should be %04.0f but is %04.0f\n", rank, i + k * sliceN, j, x1, x);
          error++;
        }
      }
    }
  }

  MPI_Barrier(MPI_COMM_WORLD);
  printf("\nprocess %d: %d errors found.\n\n", rank, error);
  MPI_Barrier(MPI_COMM_WORLD);
}

int main(int argc, char **argv)
{
  int rank, size;
  int sliceM, sliceN;
  int i, j;
  double *A, *B;
  pstopwatch sw;

  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  /* Test if both rows and columns are divisible by number of processes. */
  assert(!(M % size));
  assert(!(N % size));

  sw = new_stopwatch();

  /* Determine slice size for rows and columns. */
  sliceM = M / size;
  sliceN = N / size;

  /* Allocate memory */
  A = (double *)malloc(M * sliceN * sizeof(double));
  B = (double *)malloc(N * sliceM * sizeof(double));

  /* Init values of A with globally unique values */
  for (j = 0; j < sliceN; ++j)
  {
    for (i = 0; i < M; ++i)
    {
      A[i + j * M] = rank * 1000 + (1.0 + i + j * M);
    }
  }

  /* Transpose the matrix */
  start_stopwatch(sw);
  transpose_matrix(A, B, M, sliceN);

  /* Check the results */
  check_transpose(B, N, sliceM);

  /* Print out both matrices if the dimensions are small enough */
  if (rank == OUTPUT && N <= 32 && M <= 32)
  {
    printf("Matrix A of process %d\n", OUTPUT);
    print_matrix(A, M, sliceN);
    printf("\n\n");
    printf("Matrix B of process %d\n", OUTPUT);
    print_matrix(B, N, sliceM);
  }

  /* cleanup */

  MPI_Finalize();

  free(A);
  free(B);
  del_stopwatch(sw);

  return 0;
}
