
#ifndef WAVESTATE2D_H
#define WAVESTATE2D_H

typedef struct _wavestate2d wavestate2d;
typedef wavestate2d *pwavestate2d;
typedef const wavestate2d *pcwavestate2d;

#include <mpi.h>
#include "basic.h"

/*

Layout of the array data of the node in the top-left corner.

   bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb
   b+++++++++++++++++++++++++++++++++>>
   b+++++++++++++++++++++++++++++++++>>
   b+++++++++++++++++++++++++++++++++>>
   b+++++++++++++++++++++++++++++++++>>
   b+++++++++++++++++++++++++++++++++>>
   b+++++++++++++++++++++++++++++++++>>
   b+++++++++++++++++++++++++++++++++>>
   b+++++++++++++++++++++++++++++++++>>
   bvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvXX
   bvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvXX

 b  Constant border of the whole Grid. Repeatedly set to 0.
 +  Area which is associated with this thread.
 >  Area which belongs to the right neighbour.
 v  Area which belongs to the lower neighbour.
 X  Area which belongs to two neighbours.


Likewise for some node in the middle:

   XX^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^XX
   XX^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^XX
   <<+++++++++++++++++++++++++++++++++>>
   <<+++++++++++++++++++++++++++++++++>>
   <<+++++++++++++++++++++++++++++++++>>
   <<+++++++++++++++++++++++++++++++++>>
   <<+++++++++++++++++++++++++++++++++>>
   <<+++++++++++++++++++++++++++++++++>>
   <<+++++++++++++++++++++++++++++++++>>
   <<+++++++++++++++++++++++++++++++++>>
   XXvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvXX
   XXvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvXX

 ^ Area which belongs to the upper neighbour.
 < Area which belongs to the left neighbour.
  

 (firstx,firsty) points to the top-left "+" in the array.
 (lastx,lasty)   points to the bottom-right "+" in the array.
 
 qsizex/qsizey is the inner width/height (+) and
 psizex/psizey is the width/height of the whole array.

 The width of the border, that is shared with the neighbours, is "substeps".

*/

struct _wavestate2d
{
  int gsizex;  /* Whole Grid x dimension */
  int gsizey;  /* Whole Grid y dimension */
  int pstartx; /* Global location of patch (x dim) */
  int pstarty; /* Global location of patch (y dim) */
  real h;      /* Step width */
  real crho;   /* Elasticity / density constant */

  real *x; /* Displacements, x[ix+iy*psizex] */
  real *v; /* Velocities, v[ix+iy*psizex] */

  int psizex; /* Whole size of the patch (x dim) */
  int psizey; /* Whole size of the patch (y dim) */
  int qsizex; /* Size of the patch without borders */
  int qsizey;
  int firstx;
  int firsty;
  int lastx;
  int lasty;
  int substeps; /* Number of substeps to use */

  MPI_Comm comm;  /* MPI Communicator */
  int right_rank; /* Rank of right neighbour or -1 */
  int left_rank;  /* Rank of left neighbour or -1 */
  int upper_rank; /* Rank of upper neighbour or -1 */
  int lower_rank; /* Rank of lower neighbour or -1 */
  real *send_buf; /* Send buffer of size `2*psizey*substeps` */
  real *recv_buf; /* Recv buffer of size `2*psizey*substeps` */
};

/* Create a wavestate2d object */
pwavestate2d
new_wavestate2d(int nx, int ny, int substeps, real h, real crho);

/* Delete a wavestate2d object */
void del_wavestate2d(pwavestate2d wv);

/* Set interesting boundary values */
void boundary_wavestate2d(pwavestate2d wv, real t);

/* Perform one step of the leapfrog method */
void multileapfrog_wavestate2d(pwavestate2d wv, real t, real delta);

void print_wavestate2d(pwavestate2d wv, const char *filename);

#endif
