#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "wavestate2d.h"

/* ------------------------------------------------------------
 Create a wavestate2d object
 ------------------------------------------------------------ */

pwavestate2d new_wavestate2d(int nx, int ny, int substeps, real h, real crho)
{
  pwavestate2d wv;
  int nodecnt;
  int dims[2] = {
      0, 0};
  int periods[2] = {
      0, 0};
  int coords[2];
  int src_rank;
  int i;
  char name[255];
  int namelen;

  wv = (pwavestate2d)malloc(sizeof(wavestate2d));

  MPI_Comm_size(MPI_COMM_WORLD, &nodecnt);
  MPI_Get_processor_name(name, &namelen);

  MPI_Dims_create(nodecnt, 2, dims);
  MPI_Cart_create(MPI_COMM_WORLD, 2, dims, periods, 1, &wv->comm);
  MPI_Cart_get(wv->comm, 2, dims, periods, coords);
  MPI_Cart_shift(wv->comm, 0, -1, &src_rank, &wv->left_rank);
  MPI_Cart_shift(wv->comm, 0, 1, &src_rank, &wv->right_rank);
  MPI_Cart_shift(wv->comm, 1, -1, &src_rank, &wv->upper_rank);
  MPI_Cart_shift(wv->comm, 1, 1, &src_rank, &wv->lower_rank);

  wv->gsizex = nx + 2;
  wv->gsizey = ny + 2;
  wv->h = h;
  wv->crho = crho;
  wv->substeps = substeps;
  wv->qsizex = nx / dims[0] + (wv->right_rank == MPI_PROC_NULL ? (nx % dims[0]) : 0);
  wv->qsizey = ny / dims[1] + (wv->lower_rank == MPI_PROC_NULL ? (nx % dims[1]) : 0);
  wv->firstx = (wv->left_rank == MPI_PROC_NULL ? 1 : substeps);
  wv->firsty = (wv->upper_rank == MPI_PROC_NULL ? 1 : substeps);
  wv->lastx = wv->firstx + wv->qsizex - 1;
  wv->lasty = wv->firsty + wv->qsizey - 1;
  wv->pstartx = coords[0] * (nx / dims[0]);
  wv->pstarty = coords[1] * (ny / dims[1]);
  wv->psizex = wv->qsizex + (wv->left_rank == MPI_PROC_NULL ? 1 : substeps) + (wv->right_rank == MPI_PROC_NULL ? 1 : substeps);
  wv->psizey = wv->qsizey + (wv->upper_rank == MPI_PROC_NULL ? 1 : substeps) + (wv->lower_rank == MPI_PROC_NULL ? 1 : substeps);

  wv->x = (real *)malloc(wv->psizex * wv->psizey * sizeof(real));
  wv->v = (real *)malloc(wv->psizex * wv->psizey * sizeof(real));
  for (i = 0; i < wv->psizex * wv->psizey; ++i)
  {
    wv->x[i] = 0;
    wv->v[i] = 0;
  }
  wv->send_buf = (real *)malloc(2 * sizeof(real) * wv->psizey * substeps);
  wv->recv_buf = (real *)malloc(2 * sizeof(real) * wv->psizey * substeps);

  MPI_Comm_rank(MPI_COMM_WORLD, &src_rank);
  if (src_rank == 0)
  {
    printf("No. Nodes: %d (%d, %d)\n", nodecnt, dims[0], dims[1]);
  }

  printf("Node %d (%d,%d) (%s):\n"
         "  Allocated %dx%d Patch  at Position: %dx%d\n"
         "  Without borders: %dx%d size starting at %dx%d\n",
         src_rank, coords[0],
         coords[1], name, wv->psizex, wv->psizey, wv->pstartx, wv->pstarty, wv->qsizex,
         wv->qsizey, wv->firstx, wv->firsty);
  return wv;
}

/* ------------------------------------------------------------
 Delete a wavestate2d object
 ------------------------------------------------------------ */

void del_wavestate2d(pwavestate2d wv)
{
  free(wv->v);
  free(wv->x);
  free(wv->send_buf);
  free(wv->recv_buf);

  wv->v = 0; /* Safety measure */
  wv->x = 0;
  wv->send_buf = 0;

  free(wv);
}

/* ------------------------------------------------------------
 Set interesting boundary values
 ------------------------------------------------------------ */

static real boundary_function(real x, real t)
{
  real r = x - 0.5;

  return (t - 0.25 < r && r < t ? sin(M_PI * (r - t) / 0.125) : 0.0);
}

void boundary_wavestate2d(pwavestate2d wv, real t)
{
  real *x = wv->x;
  int nx = wv->psizex;
  int ny = wv->psizey;
  real h = wv->h;
  int ix, iy;

  /* Left boundary */
  if (wv->left_rank == MPI_PROC_NULL)
    for (iy = 0; iy < ny; iy++)
      x[iy * nx] = 0.0;

  /* Right boundary */
  if (wv->right_rank == MPI_PROC_NULL)
    for (iy = 0; iy < ny; iy++)
      x[(iy + 1) * nx - 1] = 0.0;

  /* Upper boundary */
  if (wv->upper_rank == MPI_PROC_NULL)
    for (ix = 0; ix < nx; ix++)
      x[ix] = 0.0;

  /* Lower boundary */
  if (wv->lower_rank == MPI_PROC_NULL)
    for (ix = 0; ix < nx; ix++)
      x[ix + (ny - 1) * nx] = boundary_function((wv->pstartx + ix) * h, t);
}

void multileapfrog_wavestate2d(pwavestate2d wv, real t, real delta)
{
  const int psizex = wv->psizex;
  const int psizey = wv->psizey;
  const int substeps = wv->substeps;
  const real hh = 1.0 / wv->h / wv->h;
  const real crho = wv->crho;
  real *x = wv->x;
  real *v = wv->v;

  int k, ix, iy;
  MPI_Request lrequest, rrequest, urequestx, drequestx, urequestv, drequestv;
  MPI_Status status;

  /*
           llast    lplast                         rpfirst   rfirst
   0       |        |                                    |        |
   |-------||-------|------------------------------------|-------||-------|
            |                                                    |        |
            first                                             last    psize-1

   */
  const int firstx = wv->firstx;
  const int firsty = wv->firsty;
  const int rfirstx = wv->lastx + 1;
  const int rfirsty = wv->lasty + 1;
  const int lastx = wv->lastx;
  const int lasty = wv->lasty;
  const int lplastx = firstx + substeps;
  const int lplasty = firsty + substeps;
  const int rpfirstx = lastx - substeps + 1;
  const int rpfirsty = lasty - substeps + 1;

  /* Receive from right, send to left neighbour */
  if (wv->left_rank != MPI_PROC_NULL)
  {
    /* (insert code) */
    for (iy = 0; iy < psizey; ++iy)
    {
      for (ix = firstx; ix < lplastx; ++ix)
      {
        wv->send_buf[iy + (ix - firstx) * psizey] = x[ix + iy * psizex];
      }
    }

    for (iy = 0; iy < psizey; ++iy)
    {
      for (ix = firstx; ix < lplastx; ++ix)
      {
        wv->send_buf[psizey * substeps + iy + (ix - firstx) * psizey] = v[ix + iy * psizex];
      }
    }

    MPI_Isend(wv->send_buf, 2 * psizey * substeps, MPI_REAL, wv->left_rank, 0,
              wv->comm, &lrequest);
  }
  if (wv->right_rank != MPI_PROC_NULL)
  {
    /* (insert code) */
    MPI_Recv(wv->recv_buf, 2 * psizey * substeps, MPI_REAL, wv->right_rank, 0,
             wv->comm, &status);

    for (iy = 0; iy < psizey; ++iy)
    {
      for (ix = rfirstx; ix < psizex; ++ix)
      {
        x[ix + iy * psizex] = wv->recv_buf[iy + (ix - rfirstx) * psizey];
      }
    }

    for (iy = 0; iy < psizey; ++iy)
    {
      for (ix = rfirstx; ix < psizex; ++ix)
      {
        v[ix + iy * psizex] = wv->recv_buf[psizey * substeps + iy + (ix - rfirstx) * psizey];
      }
    }
  }
  if (wv->left_rank != MPI_PROC_NULL)
  {
    MPI_Wait(&lrequest, &status);
  }

  /* Receive from left, send to right neighbour */
  if (wv->right_rank != MPI_PROC_NULL)
  {
    /* (insert code) */
    for (iy = 0; iy < psizey; ++iy)
    {
      for (ix = rpfirstx; ix < rfirstx; ++ix)
      {
        wv->send_buf[iy + (ix - rpfirstx) * psizey] = x[ix + iy * psizex];
      }
    }

    for (iy = 0; iy < psizey; ++iy)
    {
      for (ix = rpfirstx; ix < rfirstx; ++ix)
      {
        wv->send_buf[psizey * substeps + iy + (ix - rpfirstx) * psizey] = v[ix + iy * psizex];
      }
    }

    MPI_Isend(wv->send_buf, 2 * psizey * substeps, MPI_REAL, wv->right_rank, 0,
              wv->comm, &rrequest);
  }
  if (wv->left_rank != MPI_PROC_NULL)
  {
    /* (insert code) */
    MPI_Recv(wv->recv_buf, 2 * psizey * substeps, MPI_REAL, wv->left_rank, 0,
             wv->comm, &status);

    for (iy = 0; iy < psizey; ++iy)
    {
      for (ix = 0; ix < firstx; ++ix)
      {
        x[ix + iy * psizex] = wv->recv_buf[iy + ix * psizey];
      }
    }

    for (iy = 0; iy < psizey; ++iy)
    {
      for (ix = 0; ix < firstx; ++ix)
      {
        v[ix + iy * psizex] =
            wv->recv_buf[psizey * substeps + iy + ix * psizey];
      }
    }
  }
  if (wv->right_rank != MPI_PROC_NULL)
  {
    MPI_Wait(&rrequest, &status);
  }

  /* Receive from lower, send to upper neighbour */
  if (wv->upper_rank != MPI_PROC_NULL)
  {
    /* (insert code) */
    MPI_Isend(x + firsty * psizex, psizex * substeps, MPI_REAL, wv->upper_rank,
              0, wv->comm, &urequestx);
    MPI_Isend(v + firsty * psizex, psizex * substeps, MPI_REAL, wv->upper_rank,
              1, wv->comm, &urequestv);
  }
  if (wv->lower_rank != MPI_PROC_NULL)
  {
    /* (insert code) */
    MPI_Recv(x + psizex * rfirsty, psizex * substeps, MPI_REAL, wv->lower_rank,
             0, wv->comm, &status);
    MPI_Recv(v + psizex * rfirsty, psizex * substeps, MPI_REAL, wv->lower_rank,
             1, wv->comm, &status);
  }
  if (wv->upper_rank != MPI_PROC_NULL)
  {
    MPI_Wait(&urequestx, &status);
    MPI_Wait(&urequestv, &status);
  }

  /* Receive from upper, send to lower neighbour */
  if (wv->lower_rank != MPI_PROC_NULL)
  {
    /* (insert code) */
    MPI_Isend(x + rpfirsty * psizex, psizex * substeps, MPI_REAL,
              wv->lower_rank, 0, wv->comm, &drequestx);
    MPI_Isend(v + rpfirsty * psizex, psizex * substeps, MPI_REAL,
              wv->lower_rank, 1, wv->comm, &drequestv);
  }
  if (wv->upper_rank != MPI_PROC_NULL)
  {
    /* (insert code) */
    MPI_Recv(x + psizex * (firsty - substeps), psizex * substeps, MPI_REAL,
             wv->upper_rank, 0, wv->comm, &status);
    MPI_Recv(v + psizex * (firsty - substeps), psizex * substeps, MPI_REAL,
             wv->upper_rank, 1, wv->comm, &status);
  }
  if (wv->lower_rank != MPI_PROC_NULL)
  {
    MPI_Wait(&drequestx, &status);
    MPI_Wait(&drequestv, &status);
  }

  for (k = 0; k < wv->substeps; ++k)
  {
    boundary_wavestate2d(wv, t);
    /* Update velocities */
    for (iy = 1; iy < psizey - 1; ++iy)
      for (ix = 1; ix < psizex - 1; ++ix)
      {
        v[ix + iy * psizex] -= delta * crho * hh * (4.0 * x[ix + iy * psizex] - x[(ix + 1) + iy * psizex] - x[(ix - 1) + iy * psizex] - x[ix + (iy + 1) * psizex] - x[ix + (iy - 1) * psizex]);
        assert(fabs(v[ix + iy * psizex]) < 10000000.0);
      }

    /* Update displacements */
    for (iy = 1; iy < psizey - 1; ++iy)
      for (ix = 1; ix < psizex - 1; ++ix)
      {
        x[ix + iy * psizex] += delta * v[ix + iy * psizex];
        assert(fabs(x[ix + iy * psizex]) <= 10.0);
      }

    t += delta;
  }
}

void print_wavestate2d(pwavestate2d wv, const char *filename)
{
  int rank, size;
  real *mpibuf = NULL, *resbuf = NULL;
  int ix, iy, i, k;
  int metadata[4];

  const int firstx = wv->firstx;
  const int firsty = wv->firsty;
  const int lastx = wv->lastx;
  const int lasty = wv->lasty;
  const int imgsizex = wv->gsizex - 2; /* Strip the constant borders */
  const int imgsizey = wv->gsizey - 2;

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  mpibuf = (real *)malloc(wv->psizex * wv->psizey * 2 * sizeof(real));

  if (rank == 0)
  {
    resbuf = (real *)malloc(imgsizex * imgsizey * sizeof(real));
    for (ix = 0; ix < imgsizex * imgsizey; ++ix)
      resbuf[ix] = 0.0;
    for (iy = firsty; iy <= lasty; ++iy)
      for (ix = firstx; ix <= lastx; ++ix)
        resbuf[(ix - firstx) + (iy - firsty) * imgsizex] = wv->x[ix + iy * wv->psizex];
    for (i = 1; i < size; ++i)
    {
      MPI_Recv(metadata, 4, MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      MPI_Recv(mpibuf, metadata[2] * metadata[3], MPI_REAL, i, 0,
               MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      for (k = 0, iy = metadata[1]; iy < metadata[1] + metadata[3]; ++iy)
        for (ix = metadata[0]; ix < metadata[0] + metadata[2]; ++ix)
          resbuf[ix + iy * imgsizex] = mpibuf[k++];
    }
  }
  else
  {
    for (k = 0, iy = firsty; iy <= lasty; ++iy)
      for (ix = firstx; ix <= lastx; ++ix)
        mpibuf[k++] = wv->x[ix + iy * wv->psizex];
    metadata[0] = wv->pstartx;
    metadata[1] = wv->pstarty;
    metadata[2] = wv->qsizex;
    metadata[3] = wv->qsizey;
    assert(k == metadata[2] * metadata[3]);
    MPI_Send(metadata, 4, MPI_INT, 0, 0, MPI_COMM_WORLD);
    MPI_Send(mpibuf, k, MPI_REAL, 0, 0, MPI_COMM_WORLD);
  }

  if (rank == 0)
  {
    FILE *f;
    real rmax = 1, val;

    for (iy = 0; iy < imgsizey; ++iy)
    {
      for (ix = 0; ix < imgsizex; ++ix)
      {
        val = resbuf[ix + iy * imgsizex];
        if (val < -rmax)
          rmax = -val;
        else if (val > rmax)
          rmax = val;
      }
    }

    f = fopen(filename, "w");
    fprintf(f, "P2\n%d %d\n%d\n# rmax=%f\n", imgsizex, imgsizey, 255, rmax);
    for (iy = 0; iy < imgsizey; ++iy)
    {
      for (ix = 0; ix < imgsizex; ++ix)
        fprintf(f, "%4d",
                (int)(resbuf[ix + iy * imgsizex] / rmax / 2 * 255.0 + 128.0));
      fprintf(f, "\n");
    }
    fclose(f);
    free(resbuf);
  }

  free(mpibuf);
}
