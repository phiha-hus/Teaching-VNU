# thesis - Template - LaTeX

Template này hướng dẫn các bạn cách trình bày báo cáo bài tập lớn hay báo cáo Đồ án Tốt nghiệp đúng chuẩn của Viện Điện tử - Viễn thông, trường Đại học Bách khoa Hà Nội bằng cách sử dụng LaTeX thay vì sử dụng Microsoft Word như trước đây.

Các bạn có thể sử dụng Overleaf để dễ dàng edit online.

Video hướng dẫn xem tại link youtube: https://www.youtube.com/channel/UCjgclLCKov-gXznmdm38S-A
