%Nguyen Van Chuong
%% Bai1 G(s)= [ s/(s-1)^2 s/(s-1) ; (s^2+2s-9)/(s-1)(s+3) (s+4)/(s+3) ]
clear all; close all; clc
 

N1 = [0 1 3 0; 1 1 -11 9] ; Q1=[1 1 -5 3];
[A1,B1,C1,D1] = tf2ss(N1,Q1);
N2 = [1 2 -3 0; 1 2 -7 4]; Q2=[1 1 -5 3];
[A2,B2,C2,D2] = tf2ss(N2,Q2);

A = blkdiag(A1,A2);
B = blkdiag(B1,B2);
C = [C1 C2];
D = [D1 D2];

%bai1 cau b

[am,bm,cm,dm] = minreal(A,B,C,D);
 
%bai1 cau c d
% Magnitude scaling 

%help step   % See the syntax step
%-- Function File: [Y, T, X] = step (SYS)
%-- Function File: [Y, T, X] = step (SYS, T)
%-- Function File: [Y, T, X] = step (SYS, TFINAL)
%-- Function File: [Y, T, X] = step (SYS, TFINAL, DT)

sys = ss(am,bm,cm,dm) ;

figure(2); clf;
[y,t,x] = step(sys,10);
plot(t,x(:,1),t,x(:,2),t,x(:,3),t,y(:,1),t,y(:,2))
legend('x1','x2','x3','y1','y2')
title('Vẽ biểu đồ phản hồi từng bước cho hệ thống')
grid on


M1 = max(abs(x(:,1))) ; 
M2 = max(abs(x(:,2)));
M3 = max(abs(x(:,3)));
My1 = max(abs(y(:,1)));
My2 = max(abs(y(:,2)));
My = max(My1,My2);

P = [My/M1 0 0; 0 My/M2 0 ; 0 0 My/M3] ; 
am = P * am * inv(P);
bm = P * bm ;
cm = cm * inv(P) ;
sys = ss(am,bm,cm,dm) ;

figure(3); clf;
[y,t,x] = step(sys,10);
plot(t,x(:,1),t,x(:,2),t,x(:,3),t,y(:,1),t,y(:,2))
legend('x1','x2','x3','y1','y2')
grid on

M1 = max(abs(x(:,1)));
M2 = max(abs(x(:,2)));
M3 = max(abs(x(:,3)));
My1 = max(abs(y(:,1)));
My2 = max(abs(y(:,2)));
My = max(My1,My2);

disp('Tối đa của biên độ a đối với đầu vào bước là: ')
10/My;
