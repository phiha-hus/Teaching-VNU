%Nguyen Van Chuong
%Bai2 b


clear all; close all; clc
A=[0 1 0;0 0 12;0 -12 -24];
B=[ 0 0;-1250/37 0;0 20 ];
C=[1 0 0 ;0 0 0];
D=[0 0;0 0 ];

%he khong gian trang thai
[N1,D1]=ss2tf(A,B,C,D,1);
% khong diem va cuc
[Z1,P1,K1] = tf2zp(N1,D1)






