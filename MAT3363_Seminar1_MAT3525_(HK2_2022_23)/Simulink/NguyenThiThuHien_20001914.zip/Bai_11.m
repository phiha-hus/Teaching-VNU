function dxdt = Bai_11(x)
m = 1;
c = 120;
k = 5;
L = 0.2;
dxdt = (k / (x ^ 2) - c * ( x - L)) / m;