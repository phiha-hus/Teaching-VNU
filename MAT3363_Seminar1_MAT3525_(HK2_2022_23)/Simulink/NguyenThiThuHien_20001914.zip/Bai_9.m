function dydt = Bai_9(y)
m = 2;
b = 40;
c = 450;
dydt = - (b / m) * y(1) - (c / m) * y(2);